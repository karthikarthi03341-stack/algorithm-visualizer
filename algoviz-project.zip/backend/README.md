# AlgoViz Backend
npm install && npm start      # runs on http://localhost:4000

GET  /api/health
GET  /api/algorithms
GET  /api/array?size=48
POST /api/sort   { "algorithm": "merge", "array": [5,3,1,4] }
